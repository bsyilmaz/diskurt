#!/usr/bin/env node

console.log('Starting Discord Clone server...');
console.log('Node version:', process.version);
console.log('Current directory:', process.cwd());

require('./server.js'); 